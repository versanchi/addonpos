

<div class="tw-mt-auto">
  <div class="tw-mb-4 tw-ms-8 -tw-mt-1 no-print">
    <p class="tw-text-xs tw-font-normal tw-text-gray-500">
      {{ config('app.name', 'ultimatePOS') }} - <span class="tw-font-mono tw-font-medium"> V{{config('author.app_version')}}</span> | Copyright &copy; {{ date('Y') }} All rights reserved.
    </p>
  </div>
</div>